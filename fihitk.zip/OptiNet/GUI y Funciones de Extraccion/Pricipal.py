import paramiko

# Datos de conexión
raspberry_ip = "192.168.137.107"       # Cambia por la IP de tu Raspberry
usuario = "optinet"                       # Usuario SSH
contraseña = "12345678"            # Contraseña SSH

# Conexión y ejecución
try:
    cliente = paramiko.SSHClient()
    cliente.set_missing_host_key_policy(paramiko.AutoAddPolicy())  # Aceptar claves nuevas
    cliente.connect(raspberry_ip, username=usuario, password=contraseña)

    stdin, stdout, stderr = cliente.exec_command("ip neigh")
    salida = stdout.read().decode()

#    print("Salida del comando:")
#    print(salida)

    cliente.close()
except Exception as e:
    print("Error al conectar o ejecutar el comando:", e)

def funcion(ip,user,password):
    try:
        cliente = paramiko.SSHClient()
        cliente.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        cliente.connect(ip,username=user,password=password)
        
        stdin, stdout, stderr = cliente.exec_command("sudo arp-scan --interface=wlan0 --localnet")
        
        salida = stdout.read().decode()
        salida = salida.split("\n")
        for linea in salida:
            if len(linea.split("\t")) == 3:
                resultado = linea.split()
                ip_rasp = resultado[0]
                mac_rasp = resultado[1]           
    except:
        pass
    
def funcion1(ip,user,password):
    try:
        cliente = paramiko.SSHClient()
        cliente.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        cliente.connect(ip,username=user,password=password)
        
        cliente1 = paramiko.SSHClient()
        cliente1.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        cliente1.connect(ip,username=user,password=password,timeout=1)
        
        stdin, stdout, stderr = cliente.exec_command("sudo arp-scan --interface=wlan0 --localnet")
        
        salida = stdout.read().decode()
        salida = salida.split("\n")
        datos2 = []
        datos1 = []
        for linea in salida:
            if len(linea.split("\t")) == 3:
                resultado = linea.split()
                ip_rasp = resultado[0]
                mac_rasp = resultado[1]           
        for i in range(len(ip_rasp)):
            print(ip_rasp[i])
            try:
                stdin, stdout, stderr = cliente1.exec_command(f"ping -c 1 {ip_rasp[i]}")
                salida = stdout.read().decode()
                error = stderr.read().decode()
                if "1 received" in salida or "0% packet loss" in salida:
                    print(f"ping a {ip_rasp[i]} si")
            except Exception:
                pass
            
    
    except:
        pass
#funcion("192.168.137.107","optinet","12345678")
#funcion1("192.168.137.107","optinet","12345678")

from scapy.all import sniff, IP, get_if_list
from collections import defaultdict
from datetime import datetime
import os
import subprocess
import time
import threading

class paquetes:
    def ip(self):
        salida = subprocess.check_output("sudo arp-scan --interface=wlan0 --localnet", shell=True).decode("utf-8",errors="ignore").split('\n')
        self.informacion = []
        for linea in salida:
            linea = linea.split("\t")
            if len(linea) == 3:
                self.informacion.append([linea[0],linea[1]])
        return self.informacion
    def trafico_ip_en_intervalos(self, ip_objetivo: str, intervalo: float = 1.0):
        contador = {"bytes": 0, "paquetes": 0}
        lock = threading.Lock()

        def procesar_paquete(pkt):
            if IP in pkt:
                if pkt[IP].src == ip_objetivo or pkt[IP].dst == ip_objetivo:
                    print(contador["bytes"])
                    print(contador["paquetes"])
                    with lock:
                        contador["bytes"] += len(pkt)
                        contador["paquetes"] += 1

        print(f"?? Monitoreando trfico de la IP: {ip_objetivo} por {intervalo} segundos...")
        # Sniff con tiempo limitado
        sniff(prn=procesar_paquete, store=False, timeout=intervalo)

        with lock:
            print(f"[{time.strftime('%H:%M:%S')}] IP {ip_objetivo} -> "
                  f"{contador['bytes']} bytes en {contador['paquetes']} paquetes en {intervalo}s")

    def trafico_ip_puntual(self,ip_objetivo: str, duracion: float = 1.0):
        """
        Captura trafico relacionado con una IP especifica durante una ventana breve de tiempo.
        """

        print(f"?? Escaneando trafico de la IP {ip_objetivo} durante {duracion} segundos...")

        contador_bytes = 0
        contador_paquetes = 0

        def procesar(pkt):
            nonlocal contador_bytes, contador_paquetes
            if IP in pkt:
                if pkt[IP].src == ip_objetivo or pkt[IP].dst == ip_objetivo:
                    contador_bytes += len(pkt)
                    contador_paquetes += 1

        sniff(prn=procesar, store=False, timeout=duracion)

        print(f"?? Resultado puntual:")
        print(f"[{time.strftime('%H:%M:%S')}] IP {ip_objetivo} -> {contador_bytes} bytes, {contador_paquetes} paquetes")

        return contador_bytes, contador_paquetes

    def trafico_ip(self):
        #info = self.ip()  # Debe retornar lista de [ip, mac, ...]
        #for item in info:
        ip = "192.168.137.107"
        self.trafico_ip_en_intervalos(ip, intervalo=0.3)
        self.trafico_ip_puntual(ip, duracion=0.4)
                    
pack = paquetes()
#pack.ip()
pack.trafico_ip()

from scapy.all import sniff, IP, get_if_list
from collections import defaultdict
from datetime import datetime
import os

def captura_trafico_por_ip(duracion=1.0):
    trafico_por_ip = defaultdict(int)

    def procesar_paquete(paquete):
        if IP in paquete:
            ip_origen = paquete[IP].src
            trafico_por_ip[ip_origen] += len(paquete)  # Acumulamos bytes, no solo cantidad de paquetes

    interfaces = get_if_list()
    print(f"📡 Capturando durante {duracion} segundos en interfaces: {', '.join(interfaces)}...")

    sniff(
        
        iface=interfaces,
        prn=procesar_paquete,
        store=False,
        timeout=duracion
    )

    print(f"[{datetime.now().strftime('%H:%M:%S')}] 📊 Ancho de banda por IP origen (durante {duracion}s):\n")
    datos = {}
    for ip, total_bytes in sorted(trafico_por_ip.items(), key=lambda x: x[1], reverse=True):
        kbps = (total_bytes * 8) / 1024 / duracion  # Conversión a kbps
        datos[ip] = f"{kbps:.2f}"
        print(f"  {ip}: {kbps:.2f} kbps")
    print(datos)

if __name__ == "__main__":
    try:
        captura_trafico_por_ip(duracion=1.0)
    except PermissionError:
        print("🔒 Este script requiere privilegios de administrador (sudo).")
    except Exception as e:
        print(f"❌ Error al iniciar el sniffer: {e}")
