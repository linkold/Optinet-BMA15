from scapy.all import sniff, IP, get_if_list
from collections import defaultdict
from datetime import datetime
import os

# Diccionario para contar paquetes por IP origen
trafico_por_ip = defaultdict(int)

def limpiar_pantalla():
    os.system("cls" if os.name == "nt" else "clear")

def procesar_paquete(paquete):
    if IP in paquete:
        ip_origen = paquete[IP].src
        trafico_por_ip[ip_origen] += 1

        # Mostrar resumen actualizado
        limpiar_pantalla()
        print(f"[{datetime.now().strftime('%H:%M:%S')}] 📊 Tráfico por IP de origen:\n")
        for ip, cantidad in sorted(trafico_por_ip.items(), key=lambda x: x[1], reverse=True):
            print(f"  {ip}: {cantidad} paquetes")

if __name__ == "__main__":
    interfaces = get_if_list()
    print(f"🔎 Escuchando en interfaces: {', '.join(interfaces)}")

    try:
        sniff(
            iface=interfaces,
            prn=procesar_paquete,
            store=False
        )
    except PermissionError:
        print("⚠️ Este script requiere privilegios de administrador (sudo).")
    except Exception as e:
        print(f"❌ Error al iniciar el sniffer: {e}")
